<div class="admin_common_block">
    <h1>Languages</h1>
    <ul>
        <li><a href="<?php echo $data['config']['SITE_DIR']; ?>/admin/language/index">View All Languages</a></li>
        <li><a href="<?php echo $data['config']['SITE_DIR']; ?>/admin/language/add">Create Language</a></li>
    </ul>
</div>