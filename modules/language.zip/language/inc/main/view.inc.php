<style type="text/css">
#petlost_view_wrapper {
}
#petlost_view_wrapper .petlost_view_box h2 {
	margin-bottom:0px;
}
#petlost_view_wrapper .petlost_view_box {
	margin-bottom:15px;
	border-bottom:1px dotted #e0e0e0;
	padding-bottom:15px;
}
#petlost_view_wrapper .petlost_date {
	color:#909090;
	margin-bottom:10px;
	float:left;
}
#petlost_view_wrapper .petlost_social {
	margin-bottom:10px;
	float:right;
}
#petlost_view_wrapper .petlost_content {
	clear:both;
	margin-bottom:10px;
}
#petlost_view_wrapper .petlost_more {
	text-align:right;
}
</style>