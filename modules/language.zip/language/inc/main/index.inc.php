<style type="text/css">
h1.title {
	font-size:60px;
	margin-bottom:7px;
}
.table_pet {
	border-left:1px dashed #404040;
	border-top:1px dashed #404040;
}
.table_pet th, .table_pet td {
	border-bottom:1px dashed #404040;
	border-right:1px dashed #404040;
	padding:5px 12px;
}
/*#main h1 {
	border-bottom:5px solid #efefef;
	padding-bottom:5px;
}*/
#petlost_wrapper {
}
#petlost_wrapper .petlost_list_box h2 {
	margin-bottom:0px;
}
#petlost_wrapper .petlost_list_box {
	margin-bottom:15px;
	border-bottom:1px dotted #e0e0e0;
	padding-bottom:15px;
}
#petlost_wrapper .petlost_date {
	color:#909090;
	margin-bottom:10px;
}
#petlost_wrapper .petlost_desc {
	margin-bottom:10px;
}
#petlost_wrapper .petlost_more {
	text-align:right;
}
</style>