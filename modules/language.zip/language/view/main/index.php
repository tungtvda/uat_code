<h1 class="title"><?php echo $data['page']['title']; ?></h1>
<?php /*?><div id="petlost_wrapper">
  <?php if ($data['content_param']['count']>0) { ?>
  <?php for ($i=0; $i<$data['content_param']['count']; $i++) { ?>
  <div class="petlost_list_box">
    <h2><a href="/main/petlost/view/<?php echo $data['content'][$i]['ID']; ?>"><?php echo $data['content'][$i]['Name']; ?></a></h2>
    <div class="petlost_desc"><?php echo $data['content'][$i]['TypeID']; ?></div>
    <div class="petlost_desc"><?php echo $data['content'][$i]['Name']; ?></div>
    <div class="petlost_desc"><?php echo $data['content'][$i]['Description']; ?></div>
    <div class="petlost_desc"><?php echo $data['content'][$i]['Status']; ?></div>
    <div class="petlost_date"><?php echo $data['content'][$i]['DatePosted']; ?></div>
    <div class="petlost_more"><a href="<?php echo $data['config']['SITE_DIR']; ?>/main/petlost/view/<?php echo $data['content'][$i]['ID']; ?>">Read more &raquo;</a></div>
  </div>
  <?php } ?>
  <?php echo $data['content_param']['paginate']; ?>
  <?php } else { ?>
  <p>No pet losts yet.</p>
  <?php } ?>
</div>
<?php */?>
<div class="petlost_list_box block_common_pet clear">
  <?php /*?><h2><a href="<?php echo $data['config']['SITE_DIR']; ?>/main/petlost/view/<?php echo $data['content']['petlost'][$i]['ID']; ?>"><?php echo $data['content'][$i]['Name']; ?></a></h2><?php */?>
  <div style="float:left; margin-right:15px;"><img src="/themes/petstertag/img/no_image.gif" /></div>
  <div class="petlost_desc" style="float:left; width:632px;">
    <table border="0" cellspacing="0" cellpadding="0" class="table_pet">
      <tr>
        <th scope="row">Name</th>
        <td>Milo</td>
      </tr>
      <tr>
        <th scope="row">Type</th>
        <td>Dog</td>
      </tr>
      <tr>
        <th scope="row">Breed</th>
        <td>German Shepherd</td>
      </tr>
      <tr>
        <th scope="row">Sex</th>
        <td>Male</td>
      </tr>
      <tr>
        <th scope="row">Date of Birth</th>
        <td>25 December 2007</td>
      </tr>
      <tr>
        <th scope="row">Color</th>
        <td>Gold and Black</td>
      </tr>
      <tr>
        <th scope="row">Microchip No</th>
        <td>X025145</td>
      </tr>
      <tr>
        <th scope="row">Special Remarks</th>
        <td>Last seen in Jalan Ampang 4pm. Likes girls more than guys. Reward: Bear hug.</td>
      </tr>
    </table>
    <p>&nbsp;</p>
  </div>
  <div class='clear'></div>
</div>
<div class="petlost_list_box block_common_pet clear">
  <?php /*?><h2><a href="<?php echo $data['config']['SITE_DIR']; ?>/main/petlost/view/<?php echo $data['content']['petlost'][$i]['ID']; ?>"><?php echo $data['content'][$i]['Name']; ?></a></h2><?php */?>
  <div style="float:left; margin-right:15px;"><img src="/themes/petstertag/img/no_image.gif" /></div>
  <div class="petlost_desc" style="float:left; width:632px;">
    <table border="0" cellspacing="0" cellpadding="0" class="table_pet">
      <tr>
        <th scope="row">Name</th>
        <td>Milo</td>
      </tr>
      <tr>
        <th scope="row">Type</th>
        <td>Dog</td>
      </tr>
      <tr>
        <th scope="row">Breed</th>
        <td>German Shepherd</td>
      </tr>
      <tr>
        <th scope="row">Sex</th>
        <td>Male</td>
      </tr>
      <tr>
        <th scope="row">Date of Birth</th>
        <td>25 December 2007</td>
      </tr>
      <tr>
        <th scope="row">Color</th>
        <td>Gold and Black</td>
      </tr>
      <tr>
        <th scope="row">Microchip No</th>
        <td>X025145</td>
      </tr>
      <tr>
        <th scope="row">Special Remarks</th>
        <td>Last seen in Jalan Ampang 4pm. Likes girls more than guys. Reward: Bear hug.</td>
      </tr>
    </table>
    <p>&nbsp;</p>
  </div>
  <div class='clear'></div>
</div>
<div class="petlost_list_box block_common_pet clear">
  <?php /*?><h2><a href="<?php echo $data['config']['SITE_DIR']; ?>/main/petlost/view/<?php echo $data['content']['petlost'][$i]['ID']; ?>"><?php echo $data['content'][$i]['Name']; ?></a></h2><?php */?>
  <div style="float:left; margin-right:15px;"><img src="/themes/petstertag/img/no_image.gif" /></div>
  <div class="petlost_desc" style="float:left; width:632px;">
    <table border="0" cellspacing="0" cellpadding="0" class="table_pet">
      <tr>
        <th scope="row">Name</th>
        <td>Milo</td>
      </tr>
      <tr>
        <th scope="row">Type</th>
        <td>Dog</td>
      </tr>
      <tr>
        <th scope="row">Breed</th>
        <td>German Shepherd</td>
      </tr>
      <tr>
        <th scope="row">Sex</th>
        <td>Male</td>
      </tr>
      <tr>
        <th scope="row">Date of Birth</th>
        <td>25 December 2007</td>
      </tr>
      <tr>
        <th scope="row">Color</th>
        <td>Gold and Black</td>
      </tr>
      <tr>
        <th scope="row">Microchip No</th>
        <td>X025145</td>
      </tr>
      <tr>
        <th scope="row">Special Remarks</th>
        <td>Last seen in Jalan Ampang 4pm. Likes girls more than guys. Reward: Bear hug.</td>
      </tr>
    </table>
    <p>&nbsp;</p>
  </div>
  <div class='clear'></div>
</div>
