<div class="admin_common_block">
    <h1>Module Translations</h1>
    <ul>
        <li><a href="<?php echo $data['config']['SITE_DIR']; ?>/admin/moduletranslation/index">View All Module Translations</a></li>
        <li><a href="<?php echo $data['config']['SITE_DIR']; ?>/admin/moduletranslation/add">Create Module Translation</a></li>
    </ul>
</div>